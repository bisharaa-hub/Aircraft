
MINI ILS - FINAL REAL-HARDWARE VERSION
=======================================

Architecture
------------
LEFT ESP32  ─┐
CENTER ESP32 ├─ Wi-Fi hotspot ─> Ubuntu Flask server ─> Web dashboard
RIGHT ESP32 ─┘

The ESP32 firmware is identical on all three boards. Change NODE_NAME
to LEFT, CENTER, or RIGHT.

1. ESP32 SETUP
---------------
Edit esp32_node.ino:

#define NODE_NAME "LEFT"
const char* SSID = "YOUR_WIFI_NAME";
const char* PASSWORD = "YOUR_WIFI_PASSWORD";

Upload to the first board.

For board 2:
#define NODE_NAME "CENTER"

For board 3:
#define NODE_NAME "RIGHT"

All three boards must connect to the SAME Wi-Fi hotspot.

Open Serial Monitor at 115200 and record the IP address of each board.

2. UBUNTU SETUP
---------------
Copy the mini_ils folder to Ubuntu.

Install:
    sudo apt update
    sudo apt install python3-pip
    cd mini_ils
    python3 -m pip install -r requirements.txt

Edit server.py:

NODES = {
    "LEFT":   "10.193.246.133",
    "CENTER": "YOUR_CENTER_IP",
    "RIGHT":  "YOUR_RIGHT_IP",
}

Run:
    python3 server.py

Open from Ubuntu:
    http://127.0.0.1:5000

From another computer on the same network:
    http://UBUNTU_IP:5000

3. ANGLE CALIBRATION
--------------------
The displayed angle is NOT physically exact merely because RSSI exists.

The model is:

    differential_dB = filtered_LEFT - filtered_RIGHT

    lateral_offset_m = differential_dB / DB_PER_METER

    angle = atan2(abs(lateral_offset_m), distance_m)

You MUST experimentally determine DB_PER_METER for your actual antenna
placement, hotspot, runway geometry, and environment.

Recommended calibration:
    a) Keep the longitudinal distance fixed.
    b) Place the test receiver at known lateral offsets, e.g.
       -10, -5, -2, 0, +2, +5, +10 m.
    c) Record many RSSI samples at each position.
    d) Use median/mean after removing obvious outliers.
    e) Fit a calibration curve from RSSI differential to lateral offset.
    f) Put the fitted coefficient/model into server.py.

Do NOT claim "accurate angle" from an uncalibrated RSSI value.

4. TROUBLESHOOTING
------------------
Test each ESP32 directly in Ubuntu:

    wget -qO- http://ESP32_IP/data

Expected:
    {"node":"LEFT","rawRSSI":-55,...}

If it does not respond:
    ping ESP32_IP

If the ESP32 receives Wi-Fi but /data fails:
    verify the HTTP server started in Serial Monitor.

5. SECURITY
-----------
Do not publish your real Wi-Fi password. Replace it in the firmware locally.
For a production deployment, use authentication and HTTPS rather than
unauthenticated HTTP.
