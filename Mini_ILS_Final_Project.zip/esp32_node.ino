
#include <WiFi.h>
#include <WebServer.h>

/*
  MINI ILS - COMMON ESP32 NODE FIRMWARE
  -------------------------------------
  Upload this SAME firmware to all 3 ESP32 boards.

  Change ONLY NODE_NAME:
    LEFT
    CENTER
    RIGHT

  The node:
    1. Connects to the common Wi-Fi hotspot.
    2. Measures real Wi-Fi RSSI.
    3. Applies a 5-sample median filter.
    4. Exposes /data as JSON for the Ubuntu server.
    5. Exposes / for a basic health page.

  IMPORTANT:
  RSSI is the received power of the Wi-Fi access point at the node.
  It is NOT a direct geometric angle measurement. The Ubuntu server
  calculates lateral displacement/angle only after calibration.
*/

#include <WiFi.h>
#include <WebServer.h>

#define NODE_NAME "LEFT"       // <<< CHANGE TO CENTER / RIGHT
const char* SSID = "YOUR_WIFI_NAME";
const char* PASSWORD = "YOUR_WIFI_PASSWORD";

WebServer server(80);

const int FILTER_SIZE = 5;
float rssiSamples[FILTER_SIZE];
int sampleCount = 0;
int sampleIndex = 0;

unsigned long lastSampleMs = 0;
const unsigned long SAMPLE_INTERVAL_MS = 200;

float median5(const float *src, int n) {
  float a[FILTER_SIZE];
  for (int i = 0; i < n; i++) a[i] = src[i];

  for (int i = 0; i < n - 1; i++) {
    for (int j = i + 1; j < n; j++) {
      if (a[j] < a[i]) {
        float t = a[i];
        a[i] = a[j];
        a[j] = t;
      }
    }
  }
  return a[n / 2];
}

float addRSSISample(float value) {
  rssiSamples[sampleIndex] = value;
  sampleIndex = (sampleIndex + 1) % FILTER_SIZE;
  if (sampleCount < FILTER_SIZE) sampleCount++;
  return median5(rssiSamples, sampleCount);
}

float filteredRSSI() {
  if (sampleCount == 0) return (float)WiFi.RSSI();
  return median5(rssiSamples, sampleCount);
}

void sampleRSSI() {
  if (WiFi.status() != WL_CONNECTED) return;
  addRSSISample((float)WiFi.RSSI());
}

void handleRoot() {
  String s;
  s += "<!doctype html><html><body>";
  s += "<h2>Mini ILS ESP32 Node</h2>";
  s += "<p>Node: " + String(NODE_NAME) + "</p>";
  s += "<p>IP: " + WiFi.localIP().toString() + "</p>";
  s += "<p>MAC: " + WiFi.macAddress() + "</p>";
  s += "<p>RSSI: " + String(WiFi.RSSI()) + " dBm</p>";
  s += "<p>Filtered RSSI: " + String(filteredRSSI(), 1) + " dBm</p>";
  s += "<p><a href='/data'>/data</a></p>";
  s += "</body></html>";
  server.send(200, "text/html", s);
}

void handleData() {
  sampleRSSI();

  String json = "{";
  json += "\"node\":\"" + String(NODE_NAME) + "\",";
  json += "\"ip\":\"" + WiFi.localIP().toString() + "\",";
  json += "\"mac\":\"" + WiFi.macAddress() + "\",";
  json += "\"connected\":" + String(WiFi.status() == WL_CONNECTED ? "true" : "false") + ",";
  json += "\"rawRSSI\":" + String(WiFi.RSSI()) + ",";
  json += "\"filteredRSSI\":" + String(filteredRSSI(), 1) + ",";
  json += "\"samples\":" + String(sampleCount) + ",";
  json += "\"millis\":" + String(millis());
  json += "}";

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", json);
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(SSID, PASSWORD);

  Serial.print("Connecting to ");
  Serial.println(SSID);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 60) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Wi-Fi CONNECTED");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("MAC Address: ");
    Serial.println(WiFi.macAddress());
    Serial.print("Wi-Fi Channel: ");
    Serial.println(WiFi.channel());

    for (int i = 0; i < FILTER_SIZE; i++) {
      addRSSISample((float)WiFi.RSSI());
      delay(100);
    }
  } else {
    Serial.println("Wi-Fi connection FAILED");
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println(" MINI ILS ESP32 NODE");
  Serial.println("================================");
  Serial.print("NODE_NAME: ");
  Serial.println(NODE_NAME);

  connectWiFi();

  server.on("/", handleRoot);
  server.on("/data", handleData);
  server.begin();

  Serial.println("HTTP server started");
  Serial.println("Use /data for JSON");
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  server.handleClient();

  if (millis() - lastSampleMs >= SAMPLE_INTERVAL_MS) {
    lastSampleMs = millis();
    sampleRSSI();
  }
}
