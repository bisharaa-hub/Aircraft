
from flask import Flask, jsonify, send_from_directory
import requests
import time
import math
from collections import deque

app = Flask(__name__, static_folder="static", static_url_path="")

# ==========================================================
# SET THE REAL ESP32 IP ADDRESSES HERE
# ==========================================================
NODES = {
    "LEFT":   "10.193.246.133",
    "CENTER": "CHANGE_CENTER_IP",
    "RIGHT":  "CHANGE_RIGHT_IP",
}

# ==========================================================
# ANGLE CALIBRATION
# ==========================================================
# distance_m = longitudinal distance from the sensor plane to
# the reference point used for the angle estimate.
DISTANCE_M = 50.0

# Empirically measured RSSI differential per metre.
# MUST be calibrated on the real installation.
DB_PER_METER = 2.0

# Median window at the Ubuntu server as a second safety filter.
FILTER_SIZE = 5

# Hysteresis thresholds in dB.
ENTER_THRESHOLD_DB = 4.0
EXIT_THRESHOLD_DB = 2.0

TIMEOUT_SEC = 3.0

history = {
    "LEFT": deque(maxlen=FILTER_SIZE),
    "CENTER": deque(maxlen=FILTER_SIZE),
    "RIGHT": deque(maxlen=FILTER_SIZE),
}

last_good = {
    "LEFT": None,
    "CENTER": None,
    "RIGHT": None,
}

current_state = "CENTER"


def median(values):
    values = sorted(values)
    if not values:
        return None
    return values[len(values) // 2]


def read_node(name, ip):
    if not ip or ip.startswith("CHANGE_"):
        return {
            "node": name,
            "connected": False,
            "error": "IP address not configured"
        }

    try:
        r = requests.get(
            f"http://{ip}/data",
            timeout=0.8,
            headers={"Cache-Control": "no-cache"}
        )
        r.raise_for_status()
        data = r.json()

        raw = float(data.get("rawRSSI"))
        filtered = float(data.get("filteredRSSI", raw))

        history[name].append(filtered)
        filt = median(history[name])

        result = {
            "node": name,
            "ip": ip,
            "connected": True,
            "rawRSSI": raw,
            "filteredRSSI": filt,
            "nodeFilteredRSSI": filtered,
            "timestamp": time.time(),
        }
        last_good[name] = result
        return result

    except Exception as e:
        previous = last_good.get(name)
        if previous:
            result = dict(previous)
            result["connected"] = False
            result["stale"] = True
            result["error"] = str(e)
            return result

        return {
            "node": name,
            "ip": ip,
            "connected": False,
            "error": str(e)
        }


def calculate_decision(L, C, R):
    global current_state

    # A missing value cannot safely drive a new decision.
    if L is None or C is None or R is None:
        return current_state

    left_adv = L - C
    right_adv = R - C

    if current_state == "CENTER":
        if left_adv >= ENTER_THRESHOLD_DB and left_adv > right_adv:
            current_state = "LEFT"
        elif right_adv >= ENTER_THRESHOLD_DB and right_adv > left_adv:
            current_state = "RIGHT"

    elif current_state == "LEFT":
        if C - L >= EXIT_THRESHOLD_DB:
            current_state = "CENTER"

    elif current_state == "RIGHT":
        if C - R >= EXIT_THRESHOLD_DB:
            current_state = "CENTER"

    return current_state


def calculate_angle(L, R):
    if L is None or R is None:
        return {
            "differential_db": None,
            "lateral_offset_m": None,
            "angle_deg": None,
            "angle_side": "UNKNOWN"
        }

    differential = L - R

    # Empirical differential-to-offset model.
    # Positive differential means LEFT RSSI > RIGHT RSSI.
    lateral_offset = differential / DB_PER_METER

    angle_rad = math.atan2(abs(lateral_offset), max(DISTANCE_M, 0.1))
    angle_deg = math.degrees(angle_rad)

    side = "CENTER"
    if differential > 0:
        side = "LEFT"
    elif differential < 0:
        side = "RIGHT"

    return {
        "differential_db": round(differential, 2),
        "lateral_offset_m": round(lateral_offset, 3),
        "angle_deg": round(angle_deg, 3),
        "angle_side": side
    }


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/config")
def config():
    return jsonify({
        "nodes": NODES,
        "distance_m": DISTANCE_M,
        "db_per_meter": DB_PER_METER,
        "filter_size": FILTER_SIZE,
        "enter_threshold_db": ENTER_THRESHOLD_DB,
        "exit_threshold_db": EXIT_THRESHOLD_DB,
    })


@app.route("/api/data")
def api_data():
    readings = {}
    for name, ip in NODES.items():
        readings[name] = read_node(name, ip)

    L = readings["LEFT"].get("filteredRSSI")
    C = readings["CENTER"].get("filteredRSSI")
    R = readings["RIGHT"].get("filteredRSSI")

    decision = calculate_decision(L, C, R)
    angle = calculate_angle(L, R)

    connected_count = sum(
        1 for x in readings.values() if x.get("connected")
    )

    return jsonify({
        "timestamp": time.time(),
        "nodes": readings,
        "decision": decision,
        "angle": angle,
        "connected_nodes": connected_count,
        "total_nodes": 3,
        "calibration": {
            "distance_m": DISTANCE_M,
            "db_per_meter": DB_PER_METER,
            "note": "Angle requires empirical calibration on the installed system."
        }
    })


@app.route("/api/health")
def health():
    return jsonify({"status": "online", "service": "Mini ILS Flask Server"})


if __name__ == "__main__":
    print("Mini ILS server: http://0.0.0.0:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
